package com.Spring1030.service;

import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.Spring1030.domain.BoardVO;
import com.Spring1030.mapper.BoardMapper;
import com.Spring1030.service.BoardService;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardServiceTest {
	@Setter(onMethod_= {@Autowired})
	private BoardService service;
	
	@Test
	public void testExist() {
		log.info(service);
		assertNotNull(service);
	}
	
	@Test
	public void testList() {
		log.info("서비스가 들어옵니다" + service);
		service.getlist().forEach(i->log.info("여기는 서비스" +i));
	}
	
	@Test
	public void testRegister() {
		BoardVO board = new BoardVO();
		board.setTitle("written from service layer");
		board.setContent("content composed from service layer");
		board.setWriter("Monica");
		service.register(board);
	}
	
	@Test
	public void testGet() {
		log.info(service.get(5L));
	}
	
	@Test
	public void testDelete() {
		log.info("삭제 결과: " + service.remove(9L));
	}
	
	@Test
	public void testUpdate() {
		BoardVO board = service.get(14L);
		if(board==null) {
			return;
		}
		board.setTitle("modifying title from service");
		service.modify(board);
		log.info("수정 결과: " + service.modify(board));
		
	}

	
//	@Test
//	public void testGet() {
//		List<BoardVO> vo = service.get("박성연 새로작성하는 작가");
//		vo.forEach(i->log.info("박성연 작가의 작품" + i.getTitle()));
//	}

}
