package com.Spring1030.service;

import java.util.List;

import com.Spring1030.domain.BoardVO;

public interface BoardService {
	
	public void register(BoardVO board); //insert(mapper)
	public BoardVO get(Long bno); //read(mapper)
	public boolean modify(BoardVO board); //update(mapper)
	public boolean remove(Long bno); //delete(mapper)
	public List<BoardVO> getlist(); //list(mapper)

}
