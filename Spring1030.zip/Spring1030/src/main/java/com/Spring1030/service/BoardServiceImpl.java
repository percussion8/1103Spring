package com.Spring1030.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.Spring1030.domain.BoardVO;
import com.Spring1030.mapper.BoardMapper;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class BoardServiceImpl implements BoardService{  //서비스레이어
	private BoardMapper mapper;

	@Override
	public List<BoardVO> getlist() {
		System.out.println("여러개의 목록 가져오기");
		return mapper.getList();
	}

	@Override
	public void register(BoardVO board) {
		System.out.println("서비스에서 등록..." + board);
		mapper.insert(board);		
	}

	@Override
	public BoardVO get(Long bno) {
		System.out.println("서비스에서 하나 얻어오기" + bno);
		return mapper.read(bno);
	}

	@Override
	public boolean modify(BoardVO board) {
		System.out.println("서비스에서 수정하기" + board);
		return mapper.update(board) == 1;
	}

	@Override
	public boolean remove(Long bno) {
		System.out.println("서비스에서 삭제" + bno);
		return mapper.delete(bno) == 1;
	}
	
//	public List<BoardVO> get(String name) {
//		//컨트롤러에서 바로 mybatis로 가는것이 아니라 서비스레이어에서 복잡한 비즈니스로직을 구현하고
//		//그 결과를 db와 연동하는 레이어로 독립적인 presentation 레이어
//		List<BoardVO> vo =  mapper.getList();
//		for(BoardVO a : vo) {
//			if( !a.getWriter().equalsIgnoreCase(name)){
//				vo.remove(a);
//			} 
//		}
//		return vo;
//	}
	
	

}
