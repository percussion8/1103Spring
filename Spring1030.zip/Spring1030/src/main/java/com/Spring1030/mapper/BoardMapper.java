package com.Spring1030.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.Spring1030.domain.BoardVO;

public interface BoardMapper {
	//@Select("select * from tbl_board where bno>0")
	public List<BoardVO> getList();
	public void insert(BoardVO board);
	public void inserSelectKey(BoardVO board);
	//xml에 쿼리문을 저장해 실행 - mybatis
	   public BoardVO read(Long bno);
	   public int delete(Long bno);
	   
	   public int update(BoardVO board);

	
	

}
